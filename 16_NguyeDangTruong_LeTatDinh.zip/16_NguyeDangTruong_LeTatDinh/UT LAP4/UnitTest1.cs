﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MethodLibrary;

namespace UT_Lap_4_1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            long s0 = 10;
            long expectedK = 6;
            long expectedS = 15;

            long actualK = o.Sum(s0, out long actualS);

            Assert.AreEqual(expectedK, actualK);
            Assert.AreEqual(expectedS, actualS);
        }

        [TestMethod]
        public void TestMethod2()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            long s0 = 20;
            long expectedK = 7;
            long expectedS = 21;

            long actualK = o.Sum(s0, out long actualS);

            Assert.AreEqual(expectedK, actualK);
            Assert.AreEqual(expectedS, actualS);
        }

        [TestMethod]
        public void TestMethod3()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            long s0 = 30;
            long expectedK = 9;
            long expectedS = 36;

            long actualK = o.Sum(s0, out long actualS);

            Assert.AreEqual(expectedK, actualK);
            Assert.AreEqual(expectedS, actualS);
        }

        [TestMethod]
        public void TestMethod4()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            long s0 = 40;
            long expectedK = 10;
            long expectedS = 45;

            long actualK = o.Sum(s0, out long actualS);

            Assert.AreEqual(expectedK, actualK);
            Assert.AreEqual(expectedS, actualS);
        }

        [TestMethod]
        public void TestMethod5()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            long s0 = 50;
            long expectedK = 11;
            long expectedS = 55;

            long actualK = o.Sum(s0, out long actualS);

            Assert.AreEqual(expectedK, actualK);
            Assert.AreEqual(expectedS, actualS);
        }

        [TestMethod]
        public void TestMethod6()
        {
            Exception expectedException = null;
            try
            {
                MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
                long actualResult = o.Sum(-10, out long a);
            }
            catch (Exception ex)
            {
                expectedException = ex;
            }
            Assert.IsNotNull(expectedException);
        }

        [TestMethod]
        public void TestMethod7()
        {
            Exception expectedException = null;
            try
            {
                MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
                long actualResult = o.Sum(1, out long a);
            }
            catch (Exception ex)
            {
                expectedException = ex;
            }
            Assert.IsNotNull(expectedException);
        }

        [TestMethod]
        public void TestMethod8()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            long s0 = 0;
            long expectedK = 2;
            long expectedS = 1;

            long actualK = o.Sum(s0, out long actualS);

            Assert.AreEqual(expectedK, actualK);
            Assert.AreEqual(expectedS, actualS);
        }

        [TestMethod]
        public void TestMethod9()
        {
            Exception expectedException = null;
            try
            {
                MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
                long actualResult = o.Sum(-1, out long a);
            }
            catch (Exception ex)
            {
                expectedException = ex;
            }
            Assert.IsNotNull(expectedException);
        }
    }
}
