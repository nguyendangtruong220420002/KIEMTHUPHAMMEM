﻿using UI_LAP1;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Linq;


namespace UI_LAP1.Tests
{
    [TestClass()]
    public class Class1Tests
    {

        [TestMethod()]
        public void Max_ValidNumbers1()
        {
            Class1 class1 = new Class1();
            int A = 5;
            int B = 10;
            int C = 15;
            int result = class1.Max(A, B, C);
            Assert.AreEqual(15, result);
        }
        [TestMethod]
       
        public void Max_InvalidNumbers2()
        {
            Class1 class1 = new Class1();
            int A = 0;
            int B = 10;
            int C = 15;

            int result = class1.Max(A, B, C);
        }

        [TestMethod]
  
        public void Max_InvalidNumbers3()
        {
            Class1 class1 = new Class1();
            int A = 5;
            int B = 0;
            int C = 15;

            int result = class1.Max(A, B, C);
        }

        [TestMethod]
       
        public void Max_InvalidNumbers4()
        {
            Class1 class1 = new Class1();
            int A = 5;
            int B = 10;
            int C = 0;

            int result = class1.Max(A, B, C);
        }

        [TestMethod]
        
        public void Max_InvalidNumbers5()
        {
            Class1 class1 = new Class1();
            int A = 51;
            int B = 10;
            int C = 15;

            int result = class1.Max(A, B, C);
        }

        [TestMethod]
        
        public void Max_InvalidNumbers6()
        {
            Class1 class1 = new Class1();
            int A = 10;
            int B = 51;
            int C = 15;

            int result = class1.Max(A, B, C);
        }

        [TestMethod]
       
        public void Max_InvalidNumbers7()
        {
            Class1 class1 = new Class1();
            int A = 5;
            int B = 10;
            int C = 51;

            int result = class1.Max(A, B, C);
        }
        [TestMethod()]
       
        public void Max_ValidNumbers8()
        {
            Class1 class1 = new Class1();
            int A = 1;
            int B = 1;
            int C = 1;
            int result = class1.Max(A, B, C);
            Assert.AreEqual(1, result);
        }

        [TestMethod()]
        
        public void Max_ValidNumbers9()
        {
            Class1 class1 = new Class1();
            int A = 50;
            int B = 50;
            int C = 50;
            int result = class1.Max(A, B, C);
            Assert.AreEqual(50, result);
        }

        [TestMethod]
        
        public void Max_InvalidNumbers10()
        {
            Class1 class1 = new Class1();
            int A = 0;
            int B = 0;
            int C = 0;

            int result = class1.Max(A, B, C);

        }
        [TestMethod]
        
        public void Max_InvalidNumbers11()
        {
            Class1 class1 = new Class1();
            int A = 51;
            int B = 51;
            int C = 51;

            int result = class1.Max(A, B, C);
           
        }
        

        /* public TestContext TestContext { get; set; }
         [TestMethod]
         [ExpectedException(typeof(IndexOutOfRangeException))]
         [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV",
         "|DataDirectory|\\Data.csv", "Data#csv", DataAccessMethod.Sequential),
         DeploymentItem("Data.csv")]
         public void MaxTest()
         {
             Class1 class1 = new Class1();
             int A = Int32.Parse(TestContext.DataRow[0].toSing()); 
             int B = Int32.Parse(TestContext.DataRow[1].toSing()); ;
             int C = Int32.Parse(TestContext.DataRow[2].toSing()); ;
             int max = Int32.Parse(TestContext.DataRow[3].toSing()); ;
             int result = class1.Max(A, B, C);
             Assert.AreEqual(max, result);
         }*/

    }
}
