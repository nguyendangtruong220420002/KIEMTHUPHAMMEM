﻿namespace UI_LAP1
{
    public class Class1
    {
        public int Max(int A, int B, int C)
        {
            if (A < 1 || A > 50 || B < 1 || B > 50 || C < 1 || C > 50)
            {
                //throw new IndexOutOfRangeException("Nam trong khoang [1, 50].");
            }
            else
            {
                // Tìm số lớn nhất giữa A, B, C
                int max = A;
                if (B > max)
                {
                    max = B;
                }
                if (C > max)
                {
                    max = C;
                }

                return max;
            }
        }
        }
    }
}