﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UI_LAP1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_LAP1.Tests
{
    [TestClass()]
    public class Class1Tests
    {
        [TestMethod()]
        public void MaxTest()
        {
            Assert.Fail();
        }
    }
}