﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ClassLibrary4;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary4.Tests
{
    [TestClass()]
    public class Class1Tests
    {
        [TestMethod()]
        public void LargestTest()
        {
            Class1 class1 = new Class1();

            [TestMethod()]
            public void TestMethod1()
            {
                int[] a = new int[3] { 1, 2, 3 };
                int b = class1.Largest(a);
                int testResult = 3;
                Assert.AreEqual(testResult, b);
            }
            [TestMethod()]
            public void TestMethod2()
            {
                Class1 class1 = new Class1();
                int[] a = new int[1] { 14 };
                int b = class1.Largest(a);
                int testResult = 14;
                Assert.AreEqual(testResult, b);
            }
            [TestMethod()]
            public void TestMethod3()
            {
                int[] a = new int[3] { 2, 2, 2 };
                int b = class1.Largest(a);
                int testResult = 2;
                Assert.AreEqual(testResult, b);
            }

            [TestMethod()]
            public void TestMethod5()
            {
                int[] a = new int[1] { 2147483647 };
                int b = class1.Largest(a);
                int testResult = 2147483647;
                Assert.AreEqual(testResult, b);
            }
            [TestMethod()]
            public void TestMethod6()
            {
                int[] a = new int[1] { -2147483648 };
                int b = class1.Largest(a);
                int testResult = -2147483648;
                Assert.AreEqual(testResult, b);
            }
        }
    }
}