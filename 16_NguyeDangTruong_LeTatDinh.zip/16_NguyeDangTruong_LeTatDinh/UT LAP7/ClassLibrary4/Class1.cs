﻿namespace ClassLibrary4
{
    public class Class1
    {
        public int Largest(int[] a)
        {
            if (a.Length == 0)
            {
                return int.MaxValue;
            }

            int max = a[0];
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > max)
                {
                    max = a[i];
                }
            }

            return max;
        }
    }
}