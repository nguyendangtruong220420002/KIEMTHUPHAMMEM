﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MethodLibrary;

namespace UTLap3_1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(10, 30);
            double expectedResult = 32648;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod2()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(30, 80);
            double expectedResult = 81620;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod3()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(30, 150);
            double expectedResult = 205392;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod4()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(30, 250);
            double expectedResult = 436733;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod5()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(30, 380);
            double expectedResult = 780307;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod6()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(-5, 80);
            double expectedResult = -1;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod7()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(20, 10);
            double expectedResult = -1;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod8()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(30, -10);
            double expectedResult = -1;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod9()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(70, 10);
            double expectedResult = -1;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod10()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(0, 0);
            double expectedResult = 0;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod11()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(50, 100);
            double expectedResult = 81620;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod12()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(50, 101);
            double expectedResult = 83252.4;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod13()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 200);
            double expectedResult = 165935;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod14()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 201);
            double expectedResult = 167621.3;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod15()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 300);
            double expectedResult = 362395;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod16()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 301);
            double expectedResult = 364359.6;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod17()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 400);
            double expectedResult = 609015;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod18()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 401);
            double expectedResult = 611481.2;
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestMethod19()
        {
            MethodLibrary.MethodLibrary o = new MethodLibrary.MethodLibrary();
            double actualResult = o.TinhTienDien(100, 500);
            double expectedResult = 884345;
            Assert.AreEqual(expectedResult, actualResult);
        }
        
    }
}

